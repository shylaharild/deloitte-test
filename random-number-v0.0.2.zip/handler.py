import json
import random

def website(event, context):
    random_number = random.randint(1,100)
    body = {
        "message": "The random number from V0.0.2 is " + str(random_number)
    }

    response = {
        "statusCode": 200,
        "body": json.dumps(body)
    }

    return response
